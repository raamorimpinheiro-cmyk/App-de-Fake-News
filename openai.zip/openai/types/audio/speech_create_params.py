# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .speech_model import SpeechModel

__all__ = ["SpeechCreateParams", "Voice", "VoiceID"]


class SpeechCreateParams(TypedDict, total=False):
    input: Required[str]
    """The text to generate audio for. The maximum length is 4096 characters."""

    model: Required[Union[str, SpeechModel]]
    """
    One of the available
    [TTS models](https://developers.openai.com/api/docs/guides/text-to-speech):
    `tts-1`, `tts-1-hd`, `gpt-4o-mini-tts`, or `gpt-4o-mini-tts-2025-12-15`.

    Deprecated values:

    - "tts-1", "tts-1-hd", "gpt-4o-mini-tts", "gpt-4o-mini-tts-2025-12-15":
      Announced shutdown date: 2027-01-06. See
      https://developers.openai.com/api/docs/deprecations for details and
      recommended replacements.
    """

    voice: Required[Voice]
    """The voice to use when generating the audio.

    Supported built-in voices are `alloy`, `ash`, `ballad`, `coral`, `echo`,
    `fable`, `onyx`, `nova`, `sage`, `shimmer`, `verse`, `marin`, and `cedar`. You
    may also provide a custom voice object with an `id`, for example
    `{ "id": "voice_1234" }`. Previews of the voices are available in the
    [Text to speech guide](https://developers.openai.com/api/docs/guides/text-to-speech#voice-options).
    Custom voices must be created from audio samples. Voices created from text
    prompts are supported only in Live.
    """

    instructions: str
    """Control the voice of your generated audio with additional instructions.

    Does not work with `tts-1` or `tts-1-hd`.
    """

    response_format: Literal["mp3", "opus", "aac", "flac", "wav", "pcm"]
    """The format to audio in.

    Supported formats are `mp3`, `opus`, `aac`, `flac`, `wav`, and `pcm`.
    """

    speed: float
    """The speed of the generated audio.

    Select a value from `0.25` to `4.0`. `1.0` is the default.
    """

    stream_format: Literal["sse", "audio"]
    """The format to stream the audio in.

    Supported formats are `sse` and `audio`. `sse` is not supported for `tts-1` or
    `tts-1-hd`.
    """


class VoiceID(TypedDict, total=False):
    """Custom voice reference."""

    id: Required[str]
    """The custom voice ID, e.g. `voice_1234`."""


Voice: TypeAlias = Union[
    str,
    Literal[
        "alloy", "ash", "ballad", "coral", "echo", "sage", "shimmer", "verse", "marin", "cedar", "fable", "onyx", "nova"
    ],
    VoiceID,
]
